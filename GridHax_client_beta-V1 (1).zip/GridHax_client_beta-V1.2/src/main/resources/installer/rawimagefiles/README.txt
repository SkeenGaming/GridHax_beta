Incase you wish to edit the installer, here are the raw, non scaled or blured image files

Castle - Minecraft Screenshot
Lo Poly Island - Render by Humboldt123
Parlor - Screenshot (with Shaders) by Ratthew_
World - Minecraft Screenshot
