package org.kamiblue.client.event.events

import org.kamiblue.client.event.Event

class BaritoneCommandEvent(val command: String) : Event