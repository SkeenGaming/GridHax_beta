// 
// Decompiled by Procyon v0.5.36
// 

package me.zeroeightsix.kami.module.modules.dl;

import net.minecraft.util.text.Style;
import java.util.Iterator;
import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.math.BlockPos;
import java.util.function.Predicate;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.TextFormatting;
import me.zeroeightsix.kami.command.Command;
import net.minecraft.util.math.Vec3d;
import java.text.DecimalFormat;
import org.lwjgl.opengl.Display;
import net.minecraft.network.play.server.SPacketBlockChange;
import me.zeroeightsix.kami.setting.Settings;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import me.zero.alpine.listener.EventHandler;
import me.zeroeightsix.kami.event.events.PacketEvent;
import me.zero.alpine.listener.Listener;
import net.minecraft.util.math.ChunkPos;
import java.util.ArrayList;
import me.zeroeightsix.kami.setting.Setting;
import me.zeroeightsix.kami.module.Module;

@Info(name = "DL", category = Category.DL, description = "")
public class DL extends Module
{
    public Setting<Integer> x;
    public Setting<Integer> y;
    public Setting<Integer> z;
    public Setting<Boolean> latency;
    public Setting<Boolean> ignore;
    public Setting<Boolean> loadChunks;
    public Setting<Boolean> notify;
    private ArrayList<ChunkPos> loaded_chunks;
    public static final int MAX_DL_PPT = 15;
    public static DL INSTANCE;
    private long startTime;
    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener;
    @EventHandler
    private Listener<FMLNetworkEvent.ClientConnectedToServerEvent> connectedToServerEventListener;
    
    public DL() {
        this.x = this.register(Settings.i("X", 0));
        this.y = this.register(Settings.i("Y", 0));
        this.z = this.register(Settings.i("Z", 0));
        this.latency = this.register(Settings.booleanBuilder("latency").withValue(false).build());
        this.ignore = this.register(Settings.booleanBuilder("IgnoreLoaded").withValue(true).build());
        this.loadChunks = this.register(Settings.booleanBuilder("loadChunks").withValue(false).withVisibility(v -> this.ignore.getValue()).build());
        this.notify = this.register(Settings.b("Notifications", false));
        this.loaded_chunks = new ArrayList<ChunkPos>();
        this.startTime = -1L;
        SPacketBlockChange packetIn;
        ChunkPos chunkPos;
        DecimalFormat df;
        Vec3d pos1;
        final Command.ChatMessage chatMessage;
        Command.ChatMessage msg;
        final ClickEvent clickEvent;
        final Object o;
        this.receiveListener = new Listener<PacketEvent.Receive>(event -> {
            if (DL.mc.field_71439_g == null || DL.mc.field_71441_e == null) {
                return;
            }
            else {
                if (event.getPacket() instanceof SPacketBlockChange) {
                    packetIn = (SPacketBlockChange)event.getPacket();
                    chunkPos = new ChunkPos(packetIn.func_179827_b());
                    if (this.ignore.getValue()) {
                        if (!this.loaded_chunks.contains(chunkPos) && DL.mc.field_71441_e.func_175668_a(packetIn.func_179827_b(), false)) {
                            return;
                        }
                        else if (this.notify.getValue() && !Display.isActive()) {
                            this.SendMessage("DL found something.");
                        }
                    }
                    df = new DecimalFormat("#.#");
                    pos1 = new Vec3d((double)DL.mc.field_71439_g.func_180425_c().func_177958_n(), (double)packetIn.func_179827_b().func_177956_o(), (double)DL.mc.field_71439_g.func_180425_c().func_177952_p());
                    new Command.ChatMessage("&7[&aM&7] &r" + TextFormatting.RED + "[DL]: " + TextFormatting.RESET + packetIn.func_179827_b().toString() + " -> " + packetIn.func_180728_a().func_177230_c().func_149732_F() + " (" + df.format(pos1.func_72438_d(new Vec3d((Vec3i)packetIn.func_179827_b()))) + ") " + ((DL.mc.field_71439_g.field_71093_bK == -1) ? "Nether" : ""));
                    msg = chatMessage;
                    msg.func_150256_b();
                    new ClickEvent(ClickEvent.Action.RUN_COMMAND, ".dl " + packetIn.func_179827_b().func_177958_n() + " " + packetIn.func_179827_b().func_177952_p());
                    ((Style)o).func_150241_a(clickEvent);
                    DL.mc.field_71439_g.func_145747_a((ITextComponent)msg);
                    if (this.latency.getValue() && this.startTime != -1L) {
                        this.SendMessage("Latency = " + (System.currentTimeMillis() - this.startTime) + " ms");
                        this.startTime = -1L;
                    }
                    if (this.loadChunks.getValue() && this.loadChunks.isVisible() && !this.loaded_chunks.contains(chunkPos)) {
                        DL.mc.field_71441_e.func_73025_a(chunkPos.field_77276_a, chunkPos.field_77275_b, true);
                        this.loaded_chunks.add(chunkPos);
                    }
                }
                return;
            }
        }, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
        this.connectedToServerEventListener = new Listener<FMLNetworkEvent.ClientConnectedToServerEvent>(event -> this.unloadChunks(), (Predicate<FMLNetworkEvent.ClientConnectedToServerEvent>[])new Predicate[0]);
        DL.INSTANCE = this;
    }
    
    public void onEnable() {
        if (DL.mc.field_71441_e == null) {
            return;
        }
        final BlockPos pos = new BlockPos((int)this.x.getValue(), (int)this.y.getValue(), (int)this.z.getValue());
        this.startTime = System.currentTimeMillis();
        DL.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
    }
    
    public void onDisable() {
        this.startTime = -1L;
        this.unloadChunks();
    }
    
    private void unloadChunks() {
        if (DL.mc.field_71441_e != null) {
            for (final ChunkPos chunkPos : this.loaded_chunks) {
                DL.mc.field_71441_e.func_73025_a(chunkPos.field_77276_a, chunkPos.field_77275_b, false);
            }
        }
        this.loaded_chunks.clear();
    }
}
