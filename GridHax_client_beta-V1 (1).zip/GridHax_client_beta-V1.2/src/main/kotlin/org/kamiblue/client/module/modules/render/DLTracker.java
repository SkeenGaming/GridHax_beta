// 
// Decompiled by Procyon v0.5.36
// 

package me.zeroeightsix.kami.module.modules.dl;

import org.lwjgl.opengl.Display;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import java.text.DecimalFormat;
import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.client.gui.GuiDownloadTerrain;
import me.zeroeightsix.kami.util.LagCompensator;
import java.util.Iterator;
import java.util.function.Predicate;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.network.play.server.SPacketBlockChange;
import me.zeroeightsix.kami.setting.Settings;
import me.zero.alpine.listener.EventHandler;
import me.zeroeightsix.kami.event.events.PacketEvent;
import me.zero.alpine.listener.Listener;
import net.minecraft.util.math.BlockPos;
import me.zeroeightsix.kami.setting.Setting;
import me.zeroeightsix.kami.module.Module;

@Info(name = "DLTracker", category = Category.DL, description = "a")
public class DLTracker extends Module
{
    public Setting<Integer> x;
    public Setting<Integer> z;
    public Setting<Integer> timeout;
    public Setting<Boolean> debugDL;
    public Setting<Boolean> debugErrors;
    public Setting<Boolean> notify;
    public Setting<Integer> renderDistance;
    public Setting<Boolean> autoSpiral;
    public Setting<Integer> spiral_trigger;
    public Setting<Integer> spiral_ppt;
    public Setting<Integer> spiral_step_chunks;
    public Setting<Boolean> autoDisableSpiral;
    public Setting<Integer> spiral_range;
    private TrackedPlayer jew;
    private BlockPos beatPos;
    private boolean isBeating;
    public static DLTracker INSTANCE;
    @EventHandler
    Listener<PacketEvent.Receive> receiveListener;
    
    public DLTracker() {
        this.x = this.register(Settings.i("X", 0));
        this.z = this.register(Settings.i("Z", 0));
        this.timeout = this.register((Setting<Integer>)Settings.integerBuilder("TimeoutMs").withMinimum(10).withValue(2500).build());
        this.debugDL = this.register(Settings.b("debugDL", false));
        this.debugErrors = this.register(Settings.b("debugErrors", true));
        this.notify = this.register(Settings.b("Notifications", true));
        this.renderDistance = this.register((Setting<Integer>)Settings.integerBuilder("RenderDistance").withMinimum(1).withValue(4).withMaximum(8).build());
        this.autoSpiral = this.register(Settings.b("AutoSpiral", true));
        this.spiral_trigger = this.register(Settings.integerBuilder("spiral_trigger").withMinimum(2).withValue(3).withVisibility(v -> this.autoSpiral.getValue()).build());
        this.spiral_ppt = this.register(Settings.integerBuilder("spiral_ppt").withMinimum(1).withValue(4).withMaximum(15).withVisibility(v -> this.autoSpiral.getValue()).build());
        this.spiral_step_chunks = this.register(Settings.integerBuilder("spiral_step_chunks").withMinimum(1).withValue(2).withMaximum(15).withVisibility(v -> this.autoSpiral.getValue()).build());
        this.autoDisableSpiral = this.register(Settings.booleanBuilder("AutoDisableSpiral").withValue(true).withVisibility(v -> this.autoSpiral.getValue()).build());
        this.spiral_range = this.register(Settings.integerBuilder("spiral_range").withMinimum(100).withValue(1000).withVisibility(v -> this.autoSpiral.getValue() && this.autoDisableSpiral.getValue()).build());
        this.isBeating = false;
        SPacketBlockChange packetIn;
        String debug;
        final Iterator<ChunkPos> iterator;
        ChunkPos chunkPos;
        SPacketRespawn packetIn2;
        this.receiveListener = new Listener<PacketEvent.Receive>(event -> {
            if (this.jew == null) {
                return;
            }
            else {
                if (event.getPacket() instanceof SPacketBlockChange) {
                    packetIn = (SPacketBlockChange)event.getPacket();
                    debug = "unknown";
                    if (packetIn.func_179827_b().equals((Object)this.beatPos)) {
                        debug = "heartbeat";
                        this.jew.update();
                    }
                    else if (packetIn.func_179827_b().func_177956_o() != 0) {
                        return;
                    }
                    else {
                        this.jew.LastRequestedCoords.iterator();
                        while (iterator.hasNext()) {
                            chunkPos = iterator.next();
                            if (chunkPos.func_180331_a(0, 0, 0).equals((Object)packetIn.func_179827_b())) {
                                this.jew.onCoordReceive(chunkPos);
                                debug = "primary chunk";
                                break;
                            }
                        }
                    }
                    if (this.debugDL.getValue()) {
                        this.SendMessage(debug + " " + packetIn.func_179827_b().toString() + " -> " + packetIn.func_180728_a().func_177230_c().func_149732_F());
                    }
                }
                else if (event.getPacket() instanceof SPacketRespawn) {
                    packetIn2 = (SPacketRespawn)event.getPacket();
                    if (this.jew.dimension != packetIn2.func_149082_c()) {
                        this.jew.onDimensionChange(packetIn2.func_149082_c());
                    }
                }
                return;
            }
        }, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
        DLTracker.INSTANCE = this;
    }
    
    @Override
    protected void onEnable() {
        if (DLTracker.mc.field_71439_g == null || DLTracker.mc.field_71441_e == null) {
            return;
        }
        this.jew = new TrackedPlayer((int)this.x.getValue(), (int)this.z.getValue());
    }
    
    @Override
    public void onUpdate() {
        if (LagCompensator.INSTANCE.getTimeLastResponse() > 0.8 && DLTracker.mc.field_71462_r instanceof GuiDownloadTerrain) {
            return;
        }
        if (this.jew == null) {
            this.toggle();
            return;
        }
        if (this.jew.isSpiraling) {
            if (!this.jew.processSpiral(this.spiral_range.getValue()) && this.autoDisableSpiral.getValue()) {
                if (this.debugErrors.getValue()) {
                    this.SendMessage("Spiral scan failed... disabling module rip");
                }
                this.toggle();
            }
            return;
        }
        if (this.jew.requestChunks()) {
            this.isBeating = true;
            return;
        }
        if (this.isBeating) {
            this.beatPos = DLTracker.mc.field_71439_g.func_180425_c().func_177979_c(10);
            if (this.debugDL.getValue()) {
                this.SendMessage(TextFormatting.YELLOW + "BEATING...");
            }
            DLTracker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, this.beatPos, EnumFacing.UP));
            this.isBeating = false;
        }
    }
    
    @Override
    protected void onDisable() {
        if (this.jew != null) {
            this.SendMessage(this.jew.getReport());
        }
    }
    
    @Override
    public String getHudInfo() {
        if (this.jew == null || DLTracker.mc.field_71439_g == null) {
            return "";
        }
        if (this.jew.isSpiraling) {
            return "[SPIRALING] " + (this.jew.getBlockCoords().field_177962_a + this.jew.spiralX) + ", " + (this.jew.getBlockCoords().field_177961_c + this.jew.spiralZ);
        }
        final DecimalFormat df = new DecimalFormat("#");
        final Vec3d pos1 = new Vec3d((double)DLTracker.mc.field_71439_g.func_180425_c().func_177958_n(), (double)this.jew.getBlockCoords().func_177956_o(), (double)DLTracker.mc.field_71439_g.func_180425_c().func_177952_p());
        return "[" + this.jew.progress + "] " + this.jew.getBlockCoords().field_177962_a + ", " + this.jew.getBlockCoords().field_177961_c + "(" + df.format(pos1.func_72438_d(new Vec3d((Vec3i)this.jew.getBlockCoords()))) + ")";
    }
    
    private class TrackedPlayer
    {
        int dimension;
        ChunkPos estimatedCenter;
        int Render_Distance;
        int failures;
        int successful_polls;
        long sinceLast_request;
        String progress;
        List<ChunkPos> LastRequestedCoords;
        List<ChunkPos> LastReceivedCoords;
        TrackChunk[] primaryChunks;
        boolean isReadyToRequest;
        boolean isSpiraling;
        int spiralX;
        int spiralZ;
        
        private TrackedPlayer(final int X, final int Z) {
            this.progress = "|";
            this.Render_Distance = DLTracker.INSTANCE.renderDistance.getValue();
            this.primaryChunks = new TrackChunk[4];
            this.LastRequestedCoords = new ArrayList<ChunkPos>();
            this.LastReceivedCoords = new ArrayList<ChunkPos>();
            this.dimension = DLTracker.mc.field_71439_g.field_71093_bK;
            this.setBlockCoords(X, Z);
            this.initChunksUsingCenter();
            this.sinceLast_request = System.currentTimeMillis();
            this.isReadyToRequest = true;
            this.failures = 0;
            this.successful_polls = 0;
            this.isSpiraling = false;
            this.spiralX = 0;
            this.spiralZ = 0;
        }
        
        public boolean processSpiral(final int max) {
            final int steps = DLTracker.this.spiral_step_chunks.getValue() * 16;
            for (int i = 0; i < DLTracker.this.spiral_ppt.getValue(); ++i) {
                final int sx = this.spiralX + this.getBlockCoords().func_177958_n();
                final int sz = this.spiralZ + this.getBlockCoords().func_177952_p();
                final BlockPos pos = new BlockPos(sx, 0, sz);
                DLTracker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, pos, EnumFacing.UP));
                this.LastRequestedCoords.add(new ChunkPos(pos));
                if (Math.abs(this.spiralX) <= Math.abs(this.spiralZ) && (this.spiralX != this.spiralZ || this.spiralX >= 0)) {
                    this.spiralX += ((this.spiralZ >= 0) ? steps : (-steps));
                }
                else {
                    this.spiralZ += ((this.spiralX >= 0) ? (-steps) : steps);
                }
            }
            return this.spiralX < max;
        }
        
        public void resetSpiral() {
            this.isSpiraling = false;
            this.spiralX = 0;
            this.spiralZ = 0;
            this.LastRequestedCoords.clear();
        }
        
        public void onCoordReceive(final ChunkPos pos) {
            this.LastReceivedCoords.add(pos);
            this.LastRequestedCoords.remove(pos);
            if (this.isSpiraling) {
                if (DLTracker.this.debugErrors.getValue()) {
                    Module.this.SendMessage("Spiral found a target. tracking...");
                }
                this.resetSpiral();
                this.update();
            }
        }
        
        public void update() {
            switch (this.LastReceivedCoords.size()) {
                case 0: {
                    ++this.failures;
                    if (DLTracker.this.debugErrors.getValue()) {
                        Module.this.SendMessage("received 0 primary chunks, did we lose them? failures: " + this.failures);
                    }
                    if (DLTracker.this.notify.getValue() && !Display.isActive()) {
                        Module.this.SendMessage("DL tracker lost target.");
                    }
                    this.estimatedCenter = new ChunkPos(new BlockPos((int)DLTracker.this.x.getValue(), 0, (int)DLTracker.this.z.getValue()));
                    break;
                }
                case 1: {
                    this.estimatedCenter = this.LastReceivedCoords.get(0);
                    this.failures = 0;
                    break;
                }
                case 2: {
                    if (this.LastReceivedCoords.get(0).field_77276_a != this.LastReceivedCoords.get(0).field_77276_a && this.LastReceivedCoords.get(1).field_77275_b != this.LastReceivedCoords.get(1).field_77275_b && DLTracker.this.debugErrors.getValue()) {
                        Module.this.SendMessage("received two chunks that are not on a line. is this a split?");
                    }
                    this.estimatedCenter = this.average(this.LastReceivedCoords.get(0), this.LastReceivedCoords.get(1));
                    this.failures = 0;
                    break;
                }
                case 3: {
                    int i;
                    for (i = 0; i < 4; ++i) {
                        boolean exists = false;
                        for (final ChunkPos pos : this.LastReceivedCoords) {
                            if (this.primaryChunks[i].getPos().equals((Object)pos)) {
                                exists = true;
                                break;
                            }
                        }
                        if (!exists) {
                            break;
                        }
                    }
                    this.estimatedCenter = this.getOppositeCorner(i);
                    this.failures = 0;
                    break;
                }
                case 4: {
                    this.failures = 0;
                    break;
                }
            }
            this.initChunksUsingCenter();
            DLTracker.INSTANCE.x.setValue(this.getBlockCoords().field_177962_a);
            DLTracker.INSTANCE.z.setValue(this.getBlockCoords().field_177961_c);
            this.LastReceivedCoords.clear();
            this.updateProgress();
            if (this.failures == 0) {
                ++this.successful_polls;
            }
            else if (DLTracker.this.autoSpiral.getValue() && this.failures >= DLTracker.this.spiral_trigger.getValue()) {
                this.isSpiraling = true;
                if (DLTracker.this.debugErrors.getValue()) {
                    Module.this.SendMessage("Enabling Spiral Scanner...");
                }
            }
            this.isReadyToRequest = true;
        }
        
        public boolean requestChunks() {
            if (System.currentTimeMillis() - this.sinceLast_request > DLTracker.this.timeout.getValue()) {
                this.isReadyToRequest = true;
            }
            if (!this.isReadyToRequest) {
                return false;
            }
            this.LastRequestedCoords.clear();
            for (final TrackChunk trackChunk : this.primaryChunks) {
                if (DLTracker.this.debugDL.getValue()) {
                    Module.this.SendMessage(TextFormatting.YELLOW + "REQUESTING CHUNKS...");
                }
                DLTracker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, trackChunk.getBlockPos(), EnumFacing.UP));
                this.LastRequestedCoords.add(trackChunk.getPos());
            }
            this.isReadyToRequest = false;
            this.sinceLast_request = System.currentTimeMillis();
            return true;
        }
        
        void initChunksUsingCenter() {
            for (int i = 0; i < 4; ++i) {
                int X = this.estimatedCenter.field_77276_a;
                int Z = this.estimatedCenter.field_77275_b;
                switch (i) {
                    case 0: {
                        X -= this.Render_Distance;
                        Z -= this.Render_Distance;
                        break;
                    }
                    case 1: {
                        X += this.Render_Distance;
                        Z -= this.Render_Distance;
                        break;
                    }
                    case 2: {
                        X -= this.Render_Distance;
                        Z += this.Render_Distance;
                        break;
                    }
                    case 3: {
                        X += this.Render_Distance;
                        Z += this.Render_Distance;
                        break;
                    }
                }
                this.primaryChunks[i] = new TrackChunk(X, Z);
            }
        }
        
        private ChunkPos getOppositeCorner(final int index) {
            switch (index) {
                case 0: {
                    return this.primaryChunks[3].pos;
                }
                case 1: {
                    return this.primaryChunks[2].pos;
                }
                case 2: {
                    return this.primaryChunks[1].pos;
                }
                case 3: {
                    return this.primaryChunks[0].pos;
                }
                default: {
                    return this.estimatedCenter;
                }
            }
        }
        
        public void onDimensionChange(final int newDimensionID) {
            if (newDimensionID == this.dimension) {
                return;
            }
            final BlockPos old = this.getBlockCoords();
            int x = old.func_177958_n();
            int z = old.func_177952_p();
            if (newDimensionID == -1) {
                x /= 8;
                z /= 8;
                if (DLTracker.this.debugErrors.getValue()) {
                    Module.this.SendMessage("Dimension has been changed to nether.");
                }
            }
            else if (newDimensionID == 0) {
                x *= 8;
                z *= 8;
                if (DLTracker.this.debugErrors.getValue()) {
                    Module.this.SendMessage("Dimension has been changed to overworld.");
                }
            }
            this.dimension = newDimensionID;
            if (this.isSpiraling) {
                this.resetSpiral();
            }
            this.setBlockCoords(x, z);
            this.isReadyToRequest = true;
        }
        
        private BlockPos getBlockCoords() {
            return this.estimatedCenter.func_180331_a(0, 0, 0);
        }
        
        private void setBlockCoords(final int X, final int Z) {
            DLTracker.INSTANCE.x.setValue(X);
            DLTracker.INSTANCE.z.setValue(Z);
            this.estimatedCenter = new ChunkPos(new BlockPos(X, 0, Z));
        }
        
        private void updateProgress() {
            if (this.failures > 0) {
                this.progress = "!" + this.failures + "!";
            }
            else if (this.progress.contains("!")) {
                this.progress = "|";
            }
            final String progress = this.progress;
            switch (progress) {
                case "|": {
                    this.progress = "/";
                    break;
                }
                case "/": {
                    this.progress = "-";
                    break;
                }
                case "-": {
                    this.progress = "\\";
                    break;
                }
                case "\\": {
                    this.progress = "|";
                    break;
                }
            }
        }
        
        private String getReport() {
            String report = "";
            if (this.dimension == 0) {
                final String dim = "Overworld";
                final BlockPos overworld = this.getBlockCoords();
                final BlockPos nether = new BlockPos(overworld.field_177962_a / 8, 0, overworld.field_177961_c / 8);
                report = overworld.field_177962_a + ", " + overworld.field_177961_c + " in dimension " + dim + ".../ Nether coords: (" + nether.field_177962_a + ", " + nether.field_177961_c + ")";
            }
            else if (this.dimension == -1) {
                final String dim = "Nether";
                final BlockPos nether = this.getBlockCoords();
                final BlockPos overworld = new BlockPos(nether.field_177962_a * 8, 0, nether.field_177961_c * 8);
                report = nether.field_177962_a + ", " + nether.field_177961_c + " in dimension " + dim + ".../ Overworld coords: (" + overworld.field_177962_a + ", " + overworld.field_177961_c + ")";
            }
            else if (this.dimension == 1) {
                final String dim = "end";
                final BlockPos end = this.getBlockCoords();
                report = end.field_177962_a + ", " + end.field_177961_c + " in dimension " + dim;
            }
            return "Last reported coordinates: " + report + "\n Successful polls: " + this.successful_polls + " / failures before disabling module: " + this.failures;
        }
        
        private ChunkPos average(final ChunkPos first, final ChunkPos second) {
            final int X = (first.field_77276_a + second.field_77276_a) / 2;
            final int Z = (first.field_77275_b + second.field_77275_b) / 2;
            return new ChunkPos(X, Z);
        }
        
        private class TrackChunk
        {
            private ChunkPos pos;
            
            TrackChunk(final int X, final int Z) {
                this.setPos(X, Z);
            }
            
            public void setPos(final int X, final int Z) {
                this.pos = new ChunkPos(X, Z);
            }
            
            public ChunkPos getPos() {
                return this.pos;
            }
            
            public BlockPos getBlockPos() {
                return this.pos.func_180331_a(0, 0, 0);
            }
        }
    }
}
