// 
// Decompiled by Procyon v0.5.36
// 

package me.zeroeightsix.kami.module.modules.dl;

import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import me.zeroeightsix.kami.util.LagCompensator;
import me.zeroeightsix.kami.setting.Settings;
import net.minecraft.util.math.BlockPos;
import me.zeroeightsix.kami.setting.Setting;
import me.zeroeightsix.kami.module.Module;

@Info(name = "DLScanner", category = Category.DL, description = "a")
public class DLScanner extends Module
{
    public Setting<Integer> x1;
    public Setting<Integer> z1;
    public Setting<Integer> x2;
    public Setting<Integer> z2;
    private Setting<Integer> step;
    private Setting<Integer> amountPerTick;
    private Setting<Boolean> debug;
    private BlockPos pos1;
    private BlockPos pos2;
    int x;
    int z;
    public static DLScanner INSTANCE;
    
    public DLScanner() {
        this.x1 = this.register(Settings.i("X1", 0));
        this.z1 = this.register(Settings.i("Z1", 0));
        this.x2 = this.register(Settings.i("X2", 0));
        this.z2 = this.register(Settings.i("Z2", 0));
        this.step = this.register(Settings.integerBuilder("Step").withMinimum(1).withValue(144).withVisibility(v -> true).build());
        this.amountPerTick = this.register((Setting<Integer>)Settings.integerBuilder("PPT").withMinimum(1).withValue(4).withMaximum(15).build());
        this.debug = this.register(Settings.b("debug", false));
        this.pos1 = new BlockPos(0, 0, 0);
        this.pos2 = new BlockPos(0, 0, 0);
        DLScanner.INSTANCE = this;
    }
    
    @Override
    protected void onEnable() {
        this.pos1 = new BlockPos((int)this.x1.getValue(), 0, (int)this.z1.getValue());
        this.pos2 = new BlockPos((int)this.x2.getValue(), 0, (int)this.z2.getValue());
        this.x = this.pos1.field_177962_a;
        this.z = this.pos1.field_177961_c;
    }
    
    @Override
    public void onUpdate() {
        if (DLScanner.mc.field_71439_g.field_71174_a == null || DLScanner.mc.field_71441_e == null) {
            return;
        }
        if (LagCompensator.INSTANCE.getTimeLastResponse() > 0.8) {
            return;
        }
        for (int i = 0; i < this.amountPerTick.getValue(); ++i) {
            if (this.debug.getValue()) {
                this.SendMessage(this.x + ", " + this.z);
            }
            DLScanner.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, new BlockPos(this.x, 0, this.z), EnumFacing.UP));
            if (this.x < this.pos2.field_177962_a) {
                this.x += this.step.getValue();
            }
            if (this.x > this.pos2.field_177962_a) {
                this.x = this.pos1.field_177962_a;
                this.z += this.step.getValue();
            }
            if (this.z > this.pos2.field_177961_c) {
                this.SendMessage("Finished.");
                this.toggle();
                return;
            }
        }
    }
    
    @Override
    protected void onDisable() {
        this.SendMessage("Stopped at " + this.x + ", " + this.z);
    }
    
    @Override
    public String getHudInfo() {
        return this.x + ", " + this.z;
    }
}
