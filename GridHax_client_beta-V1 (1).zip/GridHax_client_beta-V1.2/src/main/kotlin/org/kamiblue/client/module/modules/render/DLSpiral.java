// 
// Decompiled by Procyon v0.5.36
// 

package me.zeroeightsix.kami.module.modules.dl;

import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import me.zeroeightsix.kami.util.LagCompensator;
import me.zeroeightsix.kami.setting.Settings;
import me.zeroeightsix.kami.setting.Setting;
import me.zeroeightsix.kami.module.Module;

@Info(name = "DLSpiral", category = Category.DL, description = "a")
public class DLSpiral extends Module
{
    public Setting<Modes> mode;
    public Setting<Integer> centerX;
    public Setting<Integer> centerZ;
    private Setting<Integer> max;
    private Setting<Integer> skip;
    private Setting<Integer> step;
    private Setting<Integer> amountPerTick;
    private Setting<Boolean> debug;
    int spiralX;
    int spiralZ;
    int sx;
    int sz;
    int center_x;
    int center_z;
    int steps;
    boolean isSkipping;
    public static DLSpiral INSTANCE;
    
    public DLSpiral() {
        this.mode = this.register(Settings.e("Mode", Modes.ZERO_ZERO));
        this.centerX = this.register(Settings.integerBuilder("centerX").withValue(0).withVisibility(v -> this.mode.getValue().equals(Modes.CUSTOM)).build());
        this.centerZ = this.register(Settings.integerBuilder("centerZ").withValue(0).withVisibility(v -> this.mode.getValue().equals(Modes.CUSTOM)).build());
        this.max = this.register((Setting<Integer>)Settings.integerBuilder("Max").withMinimum(0).withValue(0).build());
        this.skip = this.register((Setting<Integer>)Settings.integerBuilder("Skip").withMinimum(0).withValue(0).build());
        this.step = this.register(Settings.integerBuilder("Step").withMinimum(1).withValue(144).withVisibility(v -> true).build());
        this.amountPerTick = this.register((Setting<Integer>)Settings.integerBuilder("PPT").withMinimum(1).withValue(4).withMaximum(15).build());
        this.debug = this.register(Settings.b("debug", false));
        this.isSkipping = false;
        DLSpiral.INSTANCE = this;
    }
    
    @Override
    protected void onEnable() {
        if (DLSpiral.mc.field_71439_g == null) {
            return;
        }
        this.spiralX = this.skip.getValue();
        this.spiralZ = this.skip.getValue();
        if (this.mode.getValue().equals(Modes.ZERO_ZERO)) {
            this.center_x = 0;
            this.center_z = 0;
        }
        else if (this.mode.getValue().equals(Modes.YOU)) {
            this.center_x = DLSpiral.mc.field_71439_g.func_180425_c().func_177958_n();
            this.center_z = DLSpiral.mc.field_71439_g.func_180425_c().func_177952_p();
        }
        else {
            this.center_x = this.centerX.getValue();
            this.center_z = this.centerZ.getValue();
        }
        this.steps = this.step.getValue();
        this.isSkipping = (this.skip.getValue() != 0);
    }
    
    @Override
    public void onUpdate() {
        if (DLSpiral.mc.field_71439_g.field_71174_a == null) {
            return;
        }
        if (LagCompensator.INSTANCE.getTimeLastResponse() > 0.8) {
            return;
        }
        for (int i = 0; i < this.amountPerTick.getValue(); ++i) {
            this.sx = this.spiralX + this.center_x;
            this.sz = this.spiralZ + this.center_z;
            if (this.debug.getValue()) {
                this.SendMessage(this.sx + ", " + this.sz);
            }
            DLSpiral.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, new BlockPos(this.sx, 0, this.sz), EnumFacing.UP));
            if (this.isSkipping) {
                if (Math.abs(this.spiralX) < Math.abs(this.spiralZ) && (this.spiralX != this.spiralZ || this.spiralX >= 0)) {
                    this.spiralX += ((this.spiralZ >= 0) ? this.steps : (-this.steps));
                }
                else {
                    this.spiralZ += ((this.spiralX >= 0) ? (-this.steps) : this.steps);
                }
            }
            else if (Math.abs(this.spiralX) <= Math.abs(this.spiralZ) && (this.spiralX != this.spiralZ || this.spiralX >= 0)) {
                this.spiralX += ((this.spiralZ >= 0) ? this.steps : (-this.steps));
            }
            else {
                this.spiralZ += ((this.spiralX >= 0) ? (-this.steps) : this.steps);
            }
            if (this.max.getValue() >= this.steps && this.spiralX > this.max.getValue()) {
                this.spiralX = 0;
                this.spiralZ = 0;
                this.SendMessage("maximum reached, Reseting spiral relative coords and scanning again.");
            }
        }
    }
    
    @Override
    public String getHudInfo() {
        return this.sx + ", " + this.sz;
    }
    
    @Override
    protected void onDisable() {
        this.SendMessage("Stopped at " + this.sx + ", " + this.sz);
    }
    
    enum Modes
    {
        ZERO_ZERO, 
        YOU, 
        CUSTOM;
    }
}
