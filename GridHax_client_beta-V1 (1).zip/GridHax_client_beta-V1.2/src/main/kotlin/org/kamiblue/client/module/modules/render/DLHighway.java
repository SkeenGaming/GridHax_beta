// 
// Decompiled by Procyon v0.5.36
// 

package me.zeroeightsix.kami.module.modules.dl;

import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import me.zeroeightsix.kami.util.LagCompensator;
import me.zeroeightsix.kami.setting.Settings;
import net.minecraft.util.math.BlockPos;
import me.zeroeightsix.kami.setting.Setting;
import me.zeroeightsix.kami.module.Module;

@Info(name = "DLHighway", category = Category.DL, description = "a")
public class DLHighway extends Module
{
    public Setting<modes> Mode;
    public Setting<highways> axis;
    public Setting<diagonal_highways> diagonal;
    public Setting<Integer> amountPerTick;
    public Setting<Integer> step;
    public Setting<Integer> startFrom;
    private BlockPos pos;
    private int coord;
    
    public DLHighway() {
        this.Mode = this.register(Settings.e("Mode", modes.AXIS));
        this.axis = this.register((Setting<highways>)Settings.enumBuilder(highways.class).withValue(highways.PX).withName("Axis").withVisibility(o -> this.Mode.getValue().equals(modes.AXIS)).build());
        this.diagonal = this.register((Setting<diagonal_highways>)Settings.enumBuilder(diagonal_highways.class).withValue(diagonal_highways.pXpZ).withName("Diagonal").withVisibility(o -> this.Mode.getValue().equals(modes.DIAGONAL)).build());
        this.amountPerTick = this.register((Setting<Integer>)Settings.integerBuilder("PPT").withMinimum(1).withValue(4).withMaximum(15).build());
        this.step = this.register((Setting<Integer>)Settings.integerBuilder("Step").withMinimum(1).withValue(144).build());
        this.startFrom = this.register((Setting<Integer>)Settings.integerBuilder("startFrom").withMinimum(0).withValue(0).build());
        this.pos = new BlockPos(0, 0, 0);
    }
    
    @Override
    protected void onEnable() {
        this.coord = this.startFrom.getValue();
        this.pos = new BlockPos(0, 0, 0);
    }
    
    @Override
    public void onUpdate() {
        if (DLHighway.mc.field_71439_g.field_71174_a == null || DLHighway.mc.field_71441_e == null) {
            return;
        }
        if (LagCompensator.INSTANCE.getTimeLastResponse() > 0.8) {
            return;
        }
        for (int i = 0; i < this.amountPerTick.getValue(); ++i) {
            if (this.coord > 30000000) {
                this.SendMessage("Finished at 30 million. stopping.");
                this.toggle();
                return;
            }
            if (this.Mode.getValue().equals(modes.AXIS)) {
                switch (this.axis.getValue()) {
                    case NX: {
                        this.pos = new BlockPos(-this.coord, 0, 0);
                        break;
                    }
                    case NZ: {
                        this.pos = new BlockPos(0, 0, -this.coord);
                        break;
                    }
                    case PX: {
                        this.pos = new BlockPos(this.coord, 0, 0);
                        break;
                    }
                    case PZ: {
                        this.pos = new BlockPos(0, 0, this.coord);
                        break;
                    }
                }
            }
            else {
                switch (this.diagonal.getValue()) {
                    case pXpZ: {
                        this.pos = new BlockPos(this.coord, 0, this.coord);
                        break;
                    }
                    case nXnZ: {
                        this.pos = new BlockPos(-this.coord, 0, -this.coord);
                        break;
                    }
                    case pXnZ: {
                        this.pos = new BlockPos(this.coord, 0, -this.coord);
                        break;
                    }
                    case nXpZ: {
                        this.pos = new BlockPos(-this.coord, 0, this.coord);
                        break;
                    }
                }
            }
            DLHighway.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, this.pos, EnumFacing.UP));
            this.coord += this.step.getValue();
        }
    }
    
    @Override
    public String getHudInfo() {
        return this.pos.func_177958_n() + ", " + this.pos.func_177952_p();
    }
    
    enum modes
    {
        AXIS, 
        DIAGONAL;
    }
    
    enum highways
    {
        PX, 
        PZ, 
        NX, 
        NZ;
    }
    
    enum diagonal_highways
    {
        pXpZ, 
        nXnZ, 
        pXnZ, 
        nXpZ;
    }
}
