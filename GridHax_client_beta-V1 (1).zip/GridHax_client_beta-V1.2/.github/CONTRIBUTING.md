You are free to clone, modify KAMI Blue and make pull requests, provided you follow the [license](https://kamiblue.org/license).

Before contributing please see the [Code of Conduct](https://kamiblue.org/codeofconduct).

See [Support](https://kamiblue.org/support) for help.

See this [this](https://kamiblue.org/contributing) page for contributing instructions.
